# Hello Friend — Update v4.1.0

Is zip ko cPanel ke **public_html** folder mein upload karke **Extract** karo
(purani files replace ho jayengi). config.php aur upload/ ka data is zip mein nahi hai,
wo jaise hain waise rahenge.

## Upload ke baad
1. Site ek baar kholo. Auto-upgrade chalega (cache saaf, database indexes check).
2. Admin panel ka **naya address** ban jayega. Admin account se login karke
   app ka **Menu → Admin panel** dabao, wahi naya address hai.
   Purana address ab kaam nahi karega (wo public GitHub par aa chuka tha).
   File Manager mein public_html/hf-admin-path.php mein bhi likha hota hai.
   Naya address chahiye to hf-admin-path.php delete kar do, agli baar naya ban jayega.
3. Browser mein ek baar hard refresh (ya cache clear) karo taaki naya CSS/JS aaye.

## Pro/subscription
Sab members ke liye free hai. Wapas paid karna ho to phpMyAdmin mein Wo_Config table
mein hf_free_pro ki value 0 kar do.
