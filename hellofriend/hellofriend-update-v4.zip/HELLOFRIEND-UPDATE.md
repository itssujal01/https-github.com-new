# Hello Friend — Update v4.0.0

Is zip ko cPanel ke **public_html** folder mein extract karo (purani files replace ho jayengi).
config.php aur aapka upload/ data is zip mein nahi hai, wo jaise hain waise rahenge.

- Pehli baar site kholte hi ek auto-upgrade chalega (database indexes, settings, purani debug files hataana).
  Log: cache/hf-upgrade.log
- Naya admin panel address: https://hellofriend.in/hf-studio-52wi3bt9
  (purane /admin-cp aur /admincp ab kaam nahi karte)
- Admin address badalna ho to: hf-admin-path.php aur .htaccess dono mein wahi word badlo.
- Pro/subscription sab members ke liye free hai. Wapas paid karne ke liye phpMyAdmin mein
  Wo_Config table mein hf_free_pro ki value 0 kar do.
